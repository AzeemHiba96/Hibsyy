



import pandas as pd
import numpy as np
from plotly import express as px
from plotly import figure_factory as ff
from dash import html, dcc
from dash.dependencies import Input, Output
import seaborn as sns
import matplotlib.pyplot as plt

# Read the dataset
data = pd.read_csv("stroke.csv")

# Convert selected numerical columns to numeric data type
numerical_columns = ['age', 'sys_bps', 'avg_glucose_level', 'bmi', 'chol']
data[numerical_columns] = data[numerical_columns].apply(pd.to_numeric, errors='coerce')

# Handle missing values for numerical columns (replace with mean)
data[numerical_columns] = data[numerical_columns].fillna(data[numerical_columns].mean())

# Calculate the correlation matrix
correlation_matrix = data[numerical_columns].corr()

# Box plot parameters
numeric_var = 'age'
categorical_var = 'work_type'


# Define layout
data = pd.read_csv("stroke.csv")

# Convert selected numerical columns to numeric data type
numerical_columns = ['age', 'sys_bps', 'avg_glucose_level', 'bmi', 'chol']
data[numerical_columns] = data[numerical_columns].apply(pd.to_numeric, errors='coerce')

# Handle missing values for numerical columns (replace with mean)
data[numerical_columns] = data[numerical_columns].fillna(data[numerical_columns].mean())


# Define layout
layout = html.Div([
    html.H1("Bivariate Analysis of Significant Risk Factors"),

    # Age and Stroke
    dcc.Graph(
        figure=px.scatter(data, x='age', y='stroke', color='stroke', title="Age and Stroke"),
        id='age-stroke'
    ),

    # Stroke and sys_bps
    dcc.Graph(
        figure=px.scatter(data, x='sys_bps', y='stroke', color='stroke', title="Systolic Blood Pressure and Stroke"),
        id='sys-bps-stroke'
    ),

    # Age and sys_bps
    dcc.Graph(
        figure=px.scatter(data, x='age', y='sys_bps', color='stroke', title="Age and Systolic Blood Pressure"),
        id='age-sys-bps'
    ),

    # Stroke and residence_type
    dcc.Graph(
        figure=px.histogram(data, x='Residence_type', color='stroke', title="Stroke and Residence Type"),
        id='residence-type-stroke'
    ),

    # Stroke and race
    dcc.Graph(
        figure=px.histogram(data, x='race', color='stroke', title="Stroke and Race"),
        id='race-stroke'
    ),

    # Stroke and gender
    dcc.Graph(
        figure=px.histogram(data, x='gender', color='stroke', title="Stroke and Gender"),
        id='gender-stroke'
    ),

    # Race and sys_bps
    dcc.Graph(
        figure=px.scatter(data, x='race', y='sys_bps', color='stroke', title="Race and Systolic Blood Pressure"),
        id='race-sys-bps'
    ),
    dcc.Graph(
        figure=px.scatter(data, x='avg_glucose_level', y='stroke', color='stroke', title="Average Glucose Level and Stroke"),
        id='avg-glucose-level-stroke'),
    
    dcc.Graph(
        figure=px.scatter(data, x='avg_glucose_level', y='sys_bps', color='stroke', title="Average Glucose Level and Systolic Blood Pressure"),
        id='avg-glucose-level-stroke'),
    dcc.Graph(
        figure=px.scatter(data, x='age', y='avg_glucose_level', color='stroke', title="Average Glucose Level and Age"),
        id='age-avg-glucose-level'),
    # Gender and sys_bps
    dcc.Graph(
        figure=px.scatter(data, x='gender', y='sys_bps', color='stroke', title="Gender and Systolic Blood Pressure"),
        id='gender-sys-bps'
    ),
])
