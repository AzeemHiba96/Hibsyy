import pandas as pd
import numpy as np
import plotly.express as px
from dash import html, dcc, Dash
from dash.dependencies import Input, Output

# Load the dataset
data = pd.read_csv("stroke.csv")

data[['age', 'sys_bps', 'avg_glucose_level', 'bmi', 'chol']] = data[['age', 'sys_bps', 'avg_glucose_level', 'bmi', 'chol']].apply(pd.to_numeric, errors='coerce')

missing_values = ["na", "--", "-", "?", " ", "N/A", "NA"]
data = pd.read_csv('stroke.csv', na_values=missing_values)

# Handle missing values for categorical columns with the most frequent category
categorical_columns = ['race', 'gender', 'hypertension', 'ever_married', 'work_type', 'Residence_type', 'smoking_status', 'heart_disease']

for column in categorical_columns:
    most_frequent_category = data[column].mode()[0]
    data[column].fillna(most_frequent_category, inplace=True)

# Create numeric distribution plots
fig_age = px.histogram(data, x='age', title='Age')
fig_sys_bps = px.histogram(data, x='sys_bps', title='Systolic Blood Pressure')
fig_chol = px.histogram(data, x='chol', title='Cholesterol')
fig_heart_disease = px.histogram(data, x='heart_disease', title='Heart Disease')



# Create Dash layout
layout = html.Div([
    html.H1("Multivariate Analysis of Stroke with Cardiovascular Risk Factors."),
    
    dcc.Graph(figure=fig_age, id='age-histogram'),
    dcc.Graph(figure=fig_sys_bps, id='sys-bps-histogram'),
    dcc.Graph(figure=fig_chol, id='chol-histogram'),
    dcc.Graph(figure=fig_heart_disease, id='heart-disease-histogram'),

])

