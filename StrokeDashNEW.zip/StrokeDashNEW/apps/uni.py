import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.express as px

# Assuming 'app' is initialized in the 'app.py' file
from app import app
# Load the dataset
data = pd.read_csv("stroke.csv")

# Preprocessing
# 1. Coerce numerical columns
numerical_columns = ['age', 'sys_bps', 'avg_glucose_level', 'bmi', 'chol']
data[numerical_columns] = data[numerical_columns].apply(pd.to_numeric, errors='coerce')

# 2. Fill missing values for numerical columns (median for all except 'bmi', mean for 'bmi')
for col in numerical_columns:
    if col != 'bmi':
        data[col] = data[col].fillna(data[col].median())
    else:
        data[col] = data[col].fillna(data[col].mean())

# 3. Convert categorical columns to string type and fill missing values with mode
categorical_columns = ['race', 'gender', 'hypertension', 'ever_married', 'work_type', 'Residence_type', 'smoking_status', 'heart_disease']
for col in categorical_columns:
    data[col] = data[col].astype(str)
    data[col] = data[col].fillna(data[col].mode()[0])

# Dash app layout for uni.py
layout = html.Div([
    html.H1("Univariate Analysis"),

    # Dropdown for selecting data type
    dcc.Dropdown(
        id='data-type-dropdown',
        options=[
            {'label': 'Numerical', 'value': 'numerical'},
            {'label': 'Categorical', 'value': 'categorical'}
        ],
        placeholder="Select Data Type"
    ),

    # Sub-dropdown for Numerical Columns
    dcc.Dropdown(
        id='numerical-column-dropdown',
        options=[{'label': col, 'value': col} for col in numerical_columns],
        placeholder="Select Numerical Column",
        style={'display': 'none'}  # Initially hidden
    ),

    # Sub-dropdown for Categorical Columns
    dcc.Dropdown(
        id='categorical-column-dropdown',
        options=[{'label': col, 'value': col} for col in categorical_columns],
        placeholder="Select Categorical Column",
        style={'display': 'none'}  # Initially hidden
    ),

    # Div to display the plot
    html.Div(id='univariate-plot')
])

# Callback to show/hide sub-dropdowns
@app.callback(
    [Output('numerical-column-dropdown', 'style'),
     Output('categorical-column-dropdown', 'style')],
    [Input('data-type-dropdown', 'value')]
)
def set_dropdown_visibility(data_type):
    if data_type == 'numerical':
        return {'display': 'block'}, {'display': 'none'}
    elif data_type == 'categorical':
        return {'display': 'none'}, {'display': 'block'}
    return {'display': 'none'}, {'display': 'none'}

# Callback to generate plots
@app.callback(
    Output('univariate-plot', 'children'),
    [Input('numerical-column-dropdown', 'value'),
     Input('categorical-column-dropdown', 'value')]
)
def generate_plot(numerical_col, categorical_col):
    if numerical_col:
        # Numerical plot
        fig = px.box(data, x=numerical_col, title=f'Boxplot of {numerical_col}')
        return dcc.Graph(figure=fig),
         # Create a histogram for numerical columns
        fig_hist = px.histogram(data, x=numerical_col, title=f'Distribution of {numerical_col}')
        plots.append(dcc.Graph(figure=fig_hist))
    elif categorical_col:
        # Categorical plot
        fig = px.histogram(data, x=categorical_col, title=f'Distribution of {categorical_col}')
        return dcc.Graph(figure=fig)
    return html.Div()  # Empty div for no selection
