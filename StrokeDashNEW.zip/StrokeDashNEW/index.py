import dash
from dash import html, dcc
from dash.dependencies import Input, Output
# Removed unused import 'os'
# Removed importing 'data' from 'app' as it was not used
from app import app
from apps import bi, uni, multi

# Removed the outdated app.css.append_css method

# Removed the reinitialization of 'app' as it should be done in app.py

app.layout = html.Div(id='app_container', className='app-container', children=[
    dcc.Location(id='url', refresh=False),
    html.Div(
        id='top_banner',
        className='top-banner',
        children=[  
            html.H1('CEREBRO-ANALYTICS', className='header-title'),
            html.H2('NAVIGATING THE STROKE STUDY', className='header-subtitle'),
            # Move the image a bit above by reducing the negative margin-top value
            html.Img(src=app.get_asset_url('stroke1.png'), className='header-image', style={'width': '50%', 'margin-top': '-100px'}),
        ]
    ),
     html.Hr(style={
        'margin': '20px 0',
        'border': 'none',
        'height': '1px',
        'background-color': '#ccc',
        'box-shadow': '0 2px 4px rgba(0,0,0,0.5)'  # Adjust the color and spread as needed
    }),
    
    html.Div(
        className='navigation',
        style={
        'textAlign': 'center',
        'padding': '10px',
        'margin': '20px 0',
        'borderRadius': '10px',
        'boxShadow': '0 8px 20px 0px rgba(0, 0, 0, 0.2)',
        'backgroundColor': '#cf4e4b',  # Changed from backgroundImage to backgroundColor
    },
        children=[
            dcc.Link('Univariate Analysis', href='/apps/uni', className='nav-link', style={
                'fontWeight': 'bold',
                'color': 'white',
                'margin': '0 10px',
                'padding': '5px 15px',
                'display': 'inline-block',
            }),
            dcc.Link('Bivariate Analysis', href='/apps/bi', className='nav-link', style={
                'fontWeight': 'bold',
                'color': 'white',
                'margin': '0 10px',
                'padding': '5px 15px',
                'display': 'inline-block',
            }),
            dcc.Link('Multivariate Analysis', href='/apps/multi', className='nav-link', style={
                'fontWeight': 'bold',
                'color': 'white',
                'margin': '0 10px',
                'padding': '5px 15px',
                'display': 'inline-block',
            })
        ]
    ),
    html.Div(id='page_content', className='page-content'),
])
@app.callback(
    Output('page_content', 'children'),
    [Input('url', 'pathname')]
)
def display_page_content(path):
    if path == '/apps/uni':
        return uni.layout
    elif path == '/apps/bi':
        return bi.layout
    elif path == '/apps/multi':
        return multi.layout
    else:
        # Fixed the return statement
        return html.Div()




if __name__ == '__main__':
    app.run_server(debug=True)

